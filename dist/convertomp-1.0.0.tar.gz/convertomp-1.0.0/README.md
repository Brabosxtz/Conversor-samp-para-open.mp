# ConvertOMP

O `ConvertOMP` é um pacote Python que fornece ferramentas para conversão de arquivos do Samp para open.mp. Este pacote é projetado para ser simples de usar e eficiente no processo de conversão de arquivos dentro do ambiente Open-MP.

## Instalação

Para instalar o `ConvertOMP`, você pode usar o `pip` diretamente:

```bash
pip install convertomp